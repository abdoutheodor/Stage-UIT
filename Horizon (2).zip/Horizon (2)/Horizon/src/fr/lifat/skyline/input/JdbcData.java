package fr.lifat.skyline.input;

import fr.lifat.skyline.type.Tuple;
import fr.lifat.skyline.util.ErrorManager;

import java.sql.*;
import java.util.ArrayList;

public class JdbcData extends Dataset {

    private ArrayList<Tuple> data;
    private ArrayList<Integer> keys;
    private String dbUrl;
    private String dbUser;
    private String dbPassword;

    public JdbcData(String dbUrl, String dbUser, String dbPassword) {
        this.dbUrl = dbUrl;
        this.dbUser = dbUser;
        this.dbPassword = dbPassword;
    }

    public Tuple get(int n) {
        ++IO;
        return data.get(n);
    }

    @Override
    public SimpleIterator iterator() {
        return new Iterator();
    }

    @Override
    public java.util.Iterator<Integer> keyIterator() {
        return keys.iterator();
    }

    public void load(String query) {
        int id = 0;
        data = new ArrayList<>();
        keys = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (rs.next()) {
                String[] values = new String[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    values[i] = rs.getString(i + 1);
                }
                data.add(new Tuple(id, values));
                keys.add(id++);
            }
        } catch (SQLException e) {
            ErrorManager.exit(e, "Erreur lors du chargement des données JDBC.");
        }
        if (cardinality == 0) {
            cardinality = data.size();
        }
        if (dimensionality == 0) {
            dimensionality = data.get(0).size();
        }
    }

    public int size() {
        return data.size();
    }

    @Override
    public String toString() {
        return "Dataset{'" + name + ": dimensionality=" + dimensionality + ", size=" + data.size() + "}";
    }

    public class Iterator extends SimpleIterator {

        private int current = 0;

        @Override
        public SimpleIterator clone() {
            Iterator itr = new Iterator();
            itr.current = current;
            return itr;
        }

        @Override
        public void close() {
        }

        @Override
        public boolean hasNext() {
            return current < data.size();
        }

        @Override
        public Tuple next() {
            ++SIO;
            return data.get(current++);
        }
    }
}
