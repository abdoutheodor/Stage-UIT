package fr.lifat.skyline.methods;

import fr.lifat.skyline.input.Dataset;
import fr.lifat.skyline.methods.standard.BNL;

import java.util.ArrayList;

public abstract class Standard {

    public long DT = 0; // Dominance test count
    public long TT = 0; // Tested tuples
    protected Dataset dataset;
    protected String name;
    protected ArrayList<Integer> skyline = new ArrayList<>();
    protected ArrayList<Integer> subspace;

    public void assign(Dataset D) {
        dataset = D;
    }

    abstract public void build();

    public String getName() {
        return name;
    }

    public ArrayList<Integer> getSkyline() {
        return skyline;
    }

    abstract public void query();

    public void setName(String name) {
        this.name = name;
    }

    public void setSubspace(ArrayList<Integer> subspace) {
        this.subspace = subspace;
    }


}
