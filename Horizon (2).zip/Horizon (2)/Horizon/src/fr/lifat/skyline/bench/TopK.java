package fr.lifat.skyline.bench;

import fr.lifat.skyline.input.Dataset;
import fr.lifat.skyline.util.Timer;

public class TopK<D extends Dataset> {

    private final Class<D> datasetInstance;

    public TopK(Class<D> instance) {
        datasetInstance = instance;
    }

    public void run(fr.lifat.skyline.methods.TopK method, String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: " + method.getClass().getCanonicalName() + " FILE K");
            return;
        }
        String f = args[0];
        Dataset dataset = null;
        try {
            dataset = datasetInstance.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
        dataset.load(f);
        int k = Integer.parseInt(args[1]);
        method.assign(dataset);
        Timer timer = new Timer();
        timer.start();
        method.build();
        timer.stop();
        double build = timer.interval();
        System.out.println("# " + method.getName());
        System.out.println("# Build: " + build + " ms");
        System.out.println("# Cardinality: " + dataset.getCardinality());
        System.out.println("# Dimensionality: " + dataset.getDimensionality());
        timer.start();
        method.query();
        timer.stop();
        double query = timer.interval();
        double total = build + query;
        System.out.println("# Query: " + query + " ms");
        System.out.println("# Total: " + total + " ms");
        System.out.println("# Skyline: " + method.getSkyline().size());
        System.out.println("# DT: " + method.DT);
        System.out.println("# DT/Tuple: " + method.DT * 1.0 / dataset.getCardinality());
        System.out.println("# IO: " + dataset.IO);
        System.out.println("# SIO: " + dataset.SIO);
        System.out.println("# TESTED: " + method.TT);
        System.out.println("# Top " + k + " skyline:");
        int top = 0;
        for (String x : method.getSkyline(k)) {
            System.out.println("-- " + "(" + (++top) + ") " + x);
        }
    }
}
