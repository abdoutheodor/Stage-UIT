package fr.lifat.skyline.type;

public class MutableInteger implements Comparable<MutableInteger> {

    private int value;

    public MutableInteger() {
        value = 0;
    }

    public MutableInteger(int n) {
        value = n;
    }

    @Override
    public int compareTo(MutableInteger o) {
        if (value == o.value) {
            return 0;
        } else {
            return value < o.value ? -1 : 1;
        }
    }

    public int get() {
        return value;
    }

    public void increment() {
        value += 1;
    }

    public void set(int n) {
        value = n;
    }

    @Override
    public String toString() {
        return "" + value;
    }
}
