package fr.lifat.skyline.run.standard.table;

public class TableBNL {

    public static void main(String[] args) {
    }
}
