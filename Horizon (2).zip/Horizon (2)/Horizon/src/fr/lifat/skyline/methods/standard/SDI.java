package fr.lifat.skyline.methods.standard;

import fr.lifat.skyline.methods.Standard;
import fr.lifat.skyline.type.Index;
import fr.lifat.skyline.type.index.Entry;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Array-based internal memory SDI.
 *
 * @param <INDEX>
 */
public class SDI<INDEX extends Index<?>> extends Standard {

    private static final int BUILD_EXTRA = 3;
    private static final int EXTRA_MAX = 0;
    private static final int EXTRA_MIN = 1;
    private static final int EXTRA_SUM = 2;
    private static final int FLAG_PRUNED = 0x1;
    private static final int FLAG_SKYLINE = 0x2;
    private static final int FLAG_TESTED = 0x4;
    public static boolean WITH_STOPLINE = false;
    public static boolean WITH_SUBSPACE = false;
    private final Class<INDEX> indexInstance;
    private int _c = 0; // Cardinality, the number of tuples.
    private int _d = 0; // Dimensionality, the number of attributes.
    private double[][] extra; // Extra data information. *** 24N Bytes ***
    private int[] flags; // The flag for each tuple, use array for fast access. *** 4N Bytes ***
    private INDEX index; // The SDI index. *** 12dN Bytes ***
    private int[] passed; // The number of passages of each tuple. *** 4N Bytes ***
    private ArrayList<ArrayList<Integer>> skylines; // The dimensional skylines. *** Worst: 4dN Bytes ***
    private int stopline = 0; // The stop-line.
    private boolean[] stopped; // The number of stopped dimensions. *** 4N Bytes ***

    public SDI(Class<INDEX> instance) {
        setName("SDI");
        indexInstance = instance;
    }

    @Override
    public void build() {
        _c = dataset.getCardinality();
        _d = dataset.getDimensionality();
        flags = new int[_c];
        stopped = new boolean[_d];
        buildIndex();
    }

    @Override
    public void query() {
        Arrays.fill(flags, 0);
        Arrays.fill(stopped, false);
        if (!WITH_SUBSPACE || (subspace == null || subspace.isEmpty())) {
            subspace = new ArrayList<>();
            for (int i = 0; i < _d; ++i) {
                subspace.add(i);
            }
        }
        skyline.clear();
        skylines = new ArrayList<>();
        for (int ignored : subspace) {
            skylines.add(new ArrayList<>());
        }
        if (subspace.size() > BUILD_EXTRA) {
            computeExtra();
        }
        if (WITH_STOPLINE) {
            locateStopline();
        } else {
            passed = new int[_c];
            Arrays.fill(passed, 0);
        }
        boolean stop = false;
        ArrayList<Integer> block = new ArrayList<>();
        // The main loop.
        while (true) {
            // Find the best dimension.
            int b = findBestDimension();
            boolean finish = false;
            boolean repeat = false;
            // Go ahead.
            while (index.hasNext(b)) {
                Entry e = index.next(b);
                int id = e.id;
                if (!index.hasNext(b)) {
                    finish = true;
                }
                if (!finish) {
                    repeat = index.peek(b).value == e.value;
                }
                if (WITH_STOPLINE) {
                    if (id == stopline) {
                        stopped[b] = true;
                        stop = true;
                        for (int d : subspace) {
                            stop &= stopped[d];
                        }
                    }
                } else {
                    if (++passed[id] == subspace.size()) {
                        stop = true;
                    }
                }
                if ((flags[id] & FLAG_TESTED) == 0) {
                    flags[id] |= FLAG_TESTED;
                    ++TT;
                }
                if (index.previous(b) != null && e.value == index.previous(b).value) {
                    if ((flags[id] & FLAG_PRUNED) == 0) {
                        block.add(id);
                    }
                    if (!finish && repeat) {
                        continue;
                    }
                } else {
                    if (!finish && repeat) {
                        if ((flags[id] & FLAG_PRUNED) == 0) {
                            block.add(id);
                        }
                        continue;
                    }
                }
                int sky;
                if (block.isEmpty()) {
                    sky = queryTuple(id, b);
                } else {
                    if (block.size() == 1) {
                        sky = queryTuple(block.get(0), b);
                    } else {
                        sky = queryBlock(block, b);
                    }
                    block.clear();
                }
                if (stop) {
                    break;
                }
                // Do dimension switching if find any skyline tuples.
                if (sky > 0) {
                    break;
                }
            }
            // All dimensions reach the stop-line.
            if (stop) {
                break;
            }
            if (finish) {
                break;
            }
        }
    }

    private void buildIndex() {
        try {
            index = indexInstance.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
        }
        index.build(dataset);
    }

    private void computeExtra() {
        extra = new double[_c][3];
        for (int i = 0; i < _c; ++i) {
            double[] data = dataset.get(i).getData();
            double max = Integer.MIN_VALUE;
            double min = Integer.MAX_VALUE;
            double sum = 0;
            for (int d : subspace) {
                double v = data[d];
                if (v > max) {
                    max = v;
                }
                if (v < min) {
                    min = v;
                }
                sum += v;
            }
            extra[i][EXTRA_MAX] = max;
            extra[i][EXTRA_MIN] = min;
            extra[i][EXTRA_SUM] = sum;
        }
    }

    private boolean dominate(int t1, int t2) {
        if (subspace.size() > BUILD_EXTRA && isIncomparable(t1, t2)) {
            return false;
        }
        ++DT;
        return dataset.get(t1).dominates(dataset.get(t2), subspace);
    }

    private int findBestDimension() {
        int b = 0;
        // Find a non-stopped dimension.
        for (int d : subspace) {
            if (!stopped[d]) {
                b = d;
                break;
            }
        }
        // Find the best dimension.
        for (int d : subspace) {
            if (stopped[d]) {
                continue;
            }
            if (skylines.get(d).size() * 1.0 < skylines.get(b).size() * 1.0) {
                b = d;
            }
        }
        return b;
    }

    private boolean isIncomparable(int t1, int t2) {
        // Returns true of a skyline r1 is incomparable with a testing tuple r2
        // w.r.t. whether r1 dominates r2 (i.e., r1 < r2).
        return extra[t1][EXTRA_MAX] > extra[t2][EXTRA_MAX] || extra[t1][EXTRA_MIN] > extra[t2][EXTRA_MIN] || extra[t1][EXTRA_SUM] > extra[t2][EXTRA_SUM];
    }

    private void locateStopline() {
        int[] max = new int[_c];
        Arrays.fill(max, 0);
        int[] sum = new int[_c];
        Arrays.fill(sum, 0);
        stopline = 0;
        for (int d : subspace) {
            int i = 0;
            while (index.hasNext(d)) {
                Entry e = index.next(d);
                ++i;
                if (max[e.id] < i) {
                    max[e.id] = i;
                }
                sum[e.id] += i;
            }
        }
        index.reset();
        for (int i = 0; i < _c; ++i) {
            if (max[i] < max[stopline]) {
                stopline = i;
            } else if (max[i] == max[stopline]) {
                if (sum[i] < sum[stopline]) {
                    stopline = i;
                }
            }
        }
        flags[stopline] |= FLAG_SKYLINE | FLAG_TESTED;
        skyline.add(stopline);
        ++TT;
    }

    private int queryBlock(ArrayList<Integer> block, int d) {
        for (int i = 0; i < block.size() - 1; ++i) {
            if (block.get(i) < 0) {
                continue;
            }
            int i_id = block.get(i);
            boolean i_sky = (flags[i_id] & FLAG_SKYLINE) > 0;
            for (int j = i + 1; j < block.size(); ++j) {
                if (block.get(j) < 0) {
                    continue;
                }
                int j_id = block.get(j);
                boolean j_sky = (flags[j_id] & FLAG_SKYLINE) > 0;
                if (!(i_sky && j_sky)) {
                    if (!j_sky && dominate(i_id, j_id)) {
                        flags[j_id] |= FLAG_PRUNED;
                        block.set(j, -1);
                    } else if (!i_sky && dominate(j_id, i_id)) {
                        flags[i_id] |= FLAG_PRUNED;
                        block.set(i, -1);
                        break;
                    }
                }
            }
        }
        int sky = 0;
        for (int id : block) {
            if (id < 0) {
                continue;
            }
            if ((flags[id] & FLAG_SKYLINE) > 0) {
                skylines.get(d).add(id);
                ++sky;
            } else {
                if (testDominance(d, id)) {
                    flags[id] |= FLAG_PRUNED;
                } else {
                    flags[id] |= FLAG_SKYLINE;
                    skyline.add(id);
                    skylines.get(d).add(id);
                    ++sky;
                }
            }
        }
        return sky;
    }

    private int queryTuple(int id, int d) {
        if ((flags[id] & FLAG_SKYLINE) > 0) {
            skylines.get(d).add(id);
            return 1;
        } else {
            if (testDominance(d, id)) {
                flags[id] |= FLAG_PRUNED;
                return 0;
            } else {
                flags[id] |= FLAG_SKYLINE;
                skyline.add(id);
                skylines.get(d).add(id);
                return 1;
            }
        }
    }

    private boolean testDominance(int d, int t) {
        for (int s : skylines.get(d)) {
            if (dominate(s, t)) {
                return true;
            }
        }
        return false;
    }
}
