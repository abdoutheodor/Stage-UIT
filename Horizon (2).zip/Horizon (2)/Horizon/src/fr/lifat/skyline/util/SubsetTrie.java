package fr.lifat.skyline.util;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;

public class SubsetTrie<E> {

    private final int width;
    private Node<E> root;
    private int size = 0;

    public SubsetTrie(int width) {
        this.width = width;
    }

    public void add(BitSet bits, E e) {
        Node<E> node = root;
        for (int i = 0; i < width; ++i) {
            if (!bits.get(i)) {
                node = node.get(i);
            }
        }
        node.put(e);
        ++size;
    }

    public void get(BitSet bits, ArrayList<E> entries) {
        entries.clear();
        if (!root.entries.isEmpty()) {
            entries.addAll(root.entries);
        }
        for (Map.Entry<Integer, Node<E>> entry : root.nodes.entrySet()) {
            if (!bits.get(entry.getKey())) {
                get(bits, entries, entry.getValue());
            }
        }
    }

    public int size() {
        return size;
    }

    private void get(BitSet bits, ArrayList<E> entries, Node<E> node) {
        if (!node.entries.isEmpty()) {
            entries.addAll(node.entries);
        }
        for (Map.Entry<Integer, Node<E>> entry : node.nodes.entrySet()) {
            if (!bits.get(entry.getKey())) {
                get(bits, entries, entry.getValue());
            }
        }
    }

    static private class Node<E> {

        ArrayList<E> entries = new ArrayList<>();
        HashMap<Integer, Node<E>> nodes = new HashMap<>();

        public Node<E> get(int bit) {
            Node<E> node = nodes.get(bit);
            if (node == null) {
                node = new Node<E>();
                nodes.put(bit, node);
            }
            return node;
        }

        public void put(E e) {
            entries.add(e);
        }
    }
}
