package fr.lifat.skyline.util;

public class Timer {

    private double start;
    private double stop = 0;

    public Timer() {
        start = System.currentTimeMillis();
    }

    public double interval() {
        if (stop == 0) {
            stop = System.currentTimeMillis();
        }
        return stop - start;
    }

    public void start() {
        start = System.currentTimeMillis();
    }

    public void stop() {
        stop = System.currentTimeMillis();
    }
}
