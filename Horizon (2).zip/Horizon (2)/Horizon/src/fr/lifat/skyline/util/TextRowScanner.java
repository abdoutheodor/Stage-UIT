package fr.lifat.skyline.util;

import java.io.*;

public class TextRowScanner extends RowScanner {

    static private String delimiter;
    static private String filename;

    public TextRowScanner(String filename, String delimiter) {
        TextRowScanner.filename = filename;
        TextRowScanner.delimiter = delimiter;
    }

    @Override
    protected void initializeIterator() {
        iterator = new RowIterator(filename, delimiter);
    }

    private static class RowIterator implements RowIteratorInterface {

        private final String delimiter;
        private final File file;
        private BufferedReader input;
        private String line;

        public RowIterator(String filename, String delimiter) {
            this.delimiter = delimiter;
            file = filename.isEmpty() ? null : new File(filename);
            initialize();
        }

        public void close() {
            line = null;
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    ErrorManager.exit("Cannot close row scanner.");
                }
            }
        }

        public boolean hasNext() {
            return line != null;
        }

        public String[] next() {
            String values = line;
            try {
                if (line == null) {
                    return null;
                } else {
                    line = input.readLine();
                    if (line == null && input != null) {
                        input.close();
                        input = null;
                    }
                }
            } catch (Exception ex) {
                ErrorManager.exit("Cannot iterate row scanner.");
            }
            return values.split(delimiter);
        }

        public void remove() {
            throw new UnsupportedOperationException("RowIterator.remove() is not supported");
        }

        protected void finalize() throws Throwable {
            try {
                close();
            } finally {
                super.finalize();
            }
        }

        private void initialize() {
            try {
                InputStreamReader reader = file == null ? new InputStreamReader(System.in) : new FileReader(file);
                input = new BufferedReader(reader);
                line = input.readLine();
                if (line == null) {
                    input.close();
                    input = null;
                }
            } catch (IOException e) {
                ErrorManager.exit(e, "Cannot initialize row scanner.");
            }
        }
    }
}
