package fr.lifat.skyline.type.index;

import fr.lifat.skyline.input.Dataset;
import fr.lifat.skyline.type.Index;
import fr.lifat.skyline.type.Tuple;

import java.util.TreeSet;

public class TreeIndex extends Index<TreeSet<Entry>> {

    public void build(Dataset dataset) {
        super.build(dataset);
        for (int k = 0; k < dimensionality; ++k) {
            indexes.add(new TreeSet<>());
        }
        add(dataset);
        reset();
    }

    protected void add(Tuple tuple, int k) {
        indexes.get(k).add(new Entry(tuple.id, tuple.get(k)));
    }
}
