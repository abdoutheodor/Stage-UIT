package fr.lifat.skyline.methods;

import fr.lifat.skyline.input.Dataset;
import fr.lifat.skyline.type.MutableInteger;

import java.util.*;
import java.util.function.Consumer;

public abstract class TopK {

    public long DT = 0; // Dominance test count
    public long TT = 0; // Tested tuples
    protected Dataset dataset;
    protected String name;
    protected HashMap<Integer, MutableInteger> skyline = new HashMap<>();
    protected HashMap<Integer, MutableInteger> skylineSorted = new LinkedHashMap<>();
    protected ArrayList<Integer> subspace;

    public void assign(Dataset D) {
        dataset = D;
    }

    abstract public void build();

    public String getName() {
        return name;
    }

    public ArrayList<Integer> getSkyline() {
        ArrayList<Integer> all = new ArrayList<>();
        for (Map.Entry<Integer, MutableInteger> e : skyline.entrySet()) {
            all.add(e.getKey());
        }
        return all;
    }

    public ArrayList<String> getSkyline(int k) {
        if (skylineSorted.isEmpty()) {
            Consumer<Map.Entry<Integer, MutableInteger>> consumer = (Map.Entry<Integer, MutableInteger> e) -> skylineSorted.put(e.getKey(), e.getValue());
            skyline.entrySet().stream().sorted(Collections.reverseOrder(Map.Entry.comparingByValue())).forEach(consumer);
        }
        ArrayList<String> top = new ArrayList<>();
        int count = 0;
        int last = 0;
        for (Map.Entry<Integer, MutableInteger> e : skylineSorted.entrySet()) {
            int key = e.getKey();
            int value = e.getValue().get();
            if (count >= k && last != value) {
                break;
            }
            last = value;
            top.add(key + " " + e.getValue());
            ++count;
        }
        return top;
    }

    abstract public void query();

    public void setName(String name) {
        this.name = name;
    }
}
