package fr.lifat.skyline.util;

import fr.lifat.skyline.input.Dataset;

import java.util.List;

public class DominanceChecker {

    private final Dataset dataset;
    double negative = 0;
    double positive = 0;

    public DominanceChecker(Dataset dataset) {
        this.dataset = dataset;
    }

    public double checkScore(int id) {
        double score = 0;
        for (int i = 0; i < dataset.getCardinality(); ++i) {
            if (i == id) {
                continue;
            }
            if (dominate(id, i)) {
                ++score;
            }
        }
        return score;
    }

    public double checkSkyline(List<Integer> list) {
        negative = 0;
        positive = 0;
        for (int id : list) {
            if (checkSkyline(id)) {
                ++positive;
            } else {
                ++negative;
            }
        }
        return positive / (negative + positive);
    }

    public boolean checkSkyline(int id) {
        for (int i = 0; i < dataset.getCardinality(); ++i) {
            if (i == id) {
                continue;
            }
            if (dominate(i, id)) {
                return false;
            }
        }
        return true;
    }

    public boolean dominate(int s, int t) {
        double[] ds = dataset.get(s).data;
        double[] dt = dataset.get(t).data;
        int dominating = 0;
        for (int i = 0; i < ds.length; ++i) {
            if (ds[i] < dt[i]) {
                ++dominating;
            } else if (ds[i] > dt[i]) {
                return false;
            }
        }
        return dominating > 0;
    }

    public double getNegative() {
        return negative;
    }

    public double getPositive() {
        return positive;
    }
}
