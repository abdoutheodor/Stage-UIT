package fr.lifat.skyline.methods.standard.table;

/**
 * Table compatible internal/external memory SDI.
 */
public class TableSDI {

}
