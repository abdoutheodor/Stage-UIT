package fr.lifat.skyline.methods.standard;

import fr.lifat.skyline.methods.Standard;
import fr.lifat.skyline.type.Tuple;

import java.util.Arrays;

/**
 * Standard block-nested-loops algorithm with single block.
 */
public class BNL extends Standard {

    public BNL() {
        setName("BNL");
    }

    @Override
    public void build() {
    }

    @Override
    public void query() {
        TT = dataset.getCardinality();
        boolean[] sky = new boolean[dataset.getCardinality()];
        Arrays.fill(sky, true);
        for (int i = 0; i < dataset.getCardinality() - 1; ++i) {
            if (!sky[i]) {
                continue;
            }
            Tuple ti = dataset.get(i);
            for (int j = i + 1; j < dataset.getCardinality(); ++j) {
                if (!sky[j]) {
                    continue;
                }
                Tuple tj = dataset.get(j);
                if (ti.dominates(tj)) {
                    sky[j] = false;
                } else {
                    if (tj.dominates(ti)) {
                        sky[i] = false;
                    }
                    ++DT;
                }
                ++DT;
            }
        }
        for (int i = 0; i < dataset.getCardinality(); ++i) {
            if (sky[i]) {
                skyline.add(i);
            }
        }
    }
}
