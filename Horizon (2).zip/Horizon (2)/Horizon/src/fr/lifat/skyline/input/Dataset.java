package fr.lifat.skyline.input;

import fr.lifat.skyline.type.Tuple;

import java.util.Iterator;

public abstract class Dataset {

    public long IO = 0; // Random IO
    public long SIO = 0; // Sequential IO
    protected int cardinality = 0;
    protected int dimensionality = 0;
    protected String name;

    public abstract Tuple get(int n);

    public int getCardinality() {
        return cardinality;
    }

    public int getDimensionality() {
        return dimensionality;
    }

    public String getName() {
        return name;
    }

    public abstract SimpleIterator iterator();

    public abstract Iterator<Integer> keyIterator();

    public abstract void load(String filename);

    public void setCardinality(int c) {
        cardinality = c;
    }

    public void setDimensionality(int d) {
        dimensionality = d;
    }

    public int size() {
        return cardinality;
    }

    @Override
    public String toString() {
        return "Dataset{'" + name + ": cardinality=" + cardinality + ", dimensionality=" + dimensionality + "}";
    }

    public static abstract class SimpleIterator {

        public abstract SimpleIterator clone();

        public abstract void close();

        public abstract boolean hasNext();

        public abstract Tuple next();
    }
}
