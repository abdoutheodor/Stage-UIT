package fr.lifat.skyline.methods.standard;

import fr.lifat.skyline.methods.Standard;
import fr.lifat.skyline.type.Tuple;

import java.util.Arrays;

/**
 * Sorted block-nested-loops algorithm with single block.
 */
public class SFS extends Standard {

    Score[] scores;

    public SFS() {
        setName("SortedBNL");
    }

    @Override
    public void build() {
        scores = new Score[dataset.getCardinality()];
        for (int i = 0; i < dataset.getCardinality(); ++i) {
            double[] data = dataset.get(i).getData();
            double score = data[0];
            for (int d = 1; d < data.length; ++d) {
                score += data[d];
            }
            scores[i] = new Score(i, score);
        }
        Arrays.sort(scores, 0, scores.length);
    }

    @Override
    public void query() {
        TT = dataset.getCardinality();
        boolean[] sky = new boolean[dataset.getCardinality()];
        Arrays.fill(sky, true);
        for (int i = 0; i < dataset.getCardinality() - 1; ++i) {
            int t1 = scores[i].key;
            if (!sky[t1]) {
                continue;
            }
            Tuple ti = dataset.get(t1);
            for (int j = i + 1; j < dataset.getCardinality(); ++j) {
                int t2 = scores[j].key;
                if (!sky[t2]) {
                    continue;
                }
                Tuple tj = dataset.get(t2);
                if (ti.dominates(tj)) {
                    sky[t2] = false;
                }
                ++DT;
            }
        }
        for (int i = 0; i < dataset.getCardinality(); ++i) {
            if (sky[i]) {
                skyline.add(i);
            }
        }
    }

    static class Score implements Comparable<Score> {

        public int key;
        public double value;

        public Score(int k, double v) {
            key = k;
            value = v;
        }

        public int compareTo(Score s) {
            if (value < s.value) {
                return -1;
            } else if (value > s.value) {
                return 1;
            } else {
                return Integer.compare(key, s.key);
            }
        }
    }
}
