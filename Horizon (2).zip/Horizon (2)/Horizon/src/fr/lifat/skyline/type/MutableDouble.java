package fr.lifat.skyline.type;

public class MutableDouble implements Comparable<MutableDouble> {

    private double value;

    public MutableDouble() {
        value = 0;
    }

    public MutableDouble(double n) {
        value = n;
    }

    @Override
    public int compareTo(MutableDouble o) {
        if (value == o.value) {
            return 0;
        } else {
            return value < o.value ? -1 : 1;
        }
    }

    public double get() {
        return value;
    }

    public void increment(double x) {
        value += x;
    }

    public void set(double n) {
        value = n;
    }

    @Override
    public String toString() {
        return "" + value;
    }
}
