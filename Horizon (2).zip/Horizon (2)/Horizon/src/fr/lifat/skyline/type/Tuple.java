package fr.lifat.skyline.type;

import java.util.ArrayList;

public class Tuple {

    public final double[] data;
    public final int id;

    public Tuple(int id, String[] values) {
        this.id = id;
        data = new double[values.length];
        for (int i = 0; i < values.length; ++i) {
            try {
                data[i] = Double.parseDouble(values[i]);
            } catch (NumberFormatException e) {
                data[i] = Double.NaN; // ou toute autre valeur par défaut
            }
        }
    }

    public Tuple(int id, String[] values, int d) {
        this.id = id;
        data = new double[values.length];
        for (int i = 0; i < values.length; ++i) {
            try {
                data[i] = Double.parseDouble(values[i]);
            } catch (NumberFormatException e) {
                data[i] = Double.NaN; // ou toute autre valeur par défaut
            }
        }
        if (d > 0) {
            double x = data[0];
            System.arraycopy(data, 1, data, 0, d);
            data[d] = x;
        }
    }

    public Tuple(int id, double[] values) {
        this.id = id;
        data = new double[values.length];
        System.arraycopy(values, 0, data, 0, values.length);
    }

    public boolean dominates(Tuple t) {
        int dominating = 0;
        for (int d = 0; d < data.length; ++d) {
            if (Double.isNaN(data[d]) || Double.isNaN(t.data[d])) {
                continue; // ignore NaN values
            }
            if (data[d] > t.data[d]) {
                return false;
            } else if (data[d] < t.data[d]) {
                ++dominating;
            }
        }
        return dominating > 0;
    }

    public boolean dominates(Tuple t, ArrayList<Integer> subspace) {
        int dominating = 0;
        for (int d : subspace) {
            if (Double.isNaN(data[d]) || Double.isNaN(t.data[d])) {
                continue; // ignore NaN values
            }
            if (data[d] > t.data[d]) {
                return false;
            } else if (data[d] < t.data[d]) {
                ++dominating;
            }
        }
        return dominating > 0;
    }

    public double get(int n) {
        return data[n];
    }

    public double[] getData() {
        return data;
    }

    public int size() {
        return data.length;
    }
}
