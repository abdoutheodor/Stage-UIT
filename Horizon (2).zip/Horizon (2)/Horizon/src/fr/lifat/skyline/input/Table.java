package fr.lifat.skyline.input;

public class Table {

}
