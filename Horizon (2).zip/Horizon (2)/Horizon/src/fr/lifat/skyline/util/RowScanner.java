package fr.lifat.skyline.util;

import java.util.Iterator;

public abstract class RowScanner implements Iterable<String[]> {

    protected RowIteratorInterface iterator = null;

    public Iterator<String[]> iterator() {
        if (iterator == null) {
            initializeIterator();
        }
        return iterator;
    }

    abstract protected void initializeIterator();

    protected interface RowIteratorInterface extends Iterator<String[]> {

        void close();
    }
}
