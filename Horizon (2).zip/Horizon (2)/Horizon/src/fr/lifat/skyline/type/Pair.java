package fr.lifat.skyline.type;

public class Pair<K extends Comparable<K>, V extends Comparable<V>> {

    public K first;
    public V second;

    public Pair() {
    }

    public Pair(K first, V second) {
        this.first = first;
        this.second = second;
    }
}
