#!/bin/sh

mkdir -p ../bin
rm -f randdataset
cc -lm *.c -o randdataset
mv randdataset ../bin/
