package fr.lifat.skyline.run.standard.table;

public class TableSDI {

    public static void main(String[] args) {
    }
}
