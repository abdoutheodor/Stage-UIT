package fr.lifat.skyline.type.index;

public class Entry implements Comparable<Entry> {

    public final int id;
    public final double value;
    //public boolean wrap = false;

    Entry(int id, double value) {
        this.id = id;
        this.value = value;
    }

    public int compareTo(Entry e) {
        if (value < e.value) {
            return -1;
        } else if (value > e.value) {
            return 1;
        } else {
            return Integer.compare(id, e.id);
        }
    }

    @Override
    public String toString() {
        return value + ":" + id;
    }
}
