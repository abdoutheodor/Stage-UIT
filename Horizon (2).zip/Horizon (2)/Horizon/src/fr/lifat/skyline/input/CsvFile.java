package fr.lifat.skyline.input;

import fr.lifat.skyline.type.Tuple;
import fr.lifat.skyline.util.RowScanner;
import fr.lifat.skyline.util.TextRowScanner;

import java.util.ArrayList;

public class CsvFile extends Dataset {

    private ArrayList<Tuple> data;
    private ArrayList<Integer> keys;

    public Tuple get(int n) {
        ++IO;
        return data.get(n);
    }

    @Override
    public SimpleIterator iterator() {
        return new Iterator();
    }

    @Override
    public java.util.Iterator<Integer> keyIterator() {
        return keys.iterator();
    }

    public void load(String filename) {
        int id = 0;
        data = new ArrayList<>();
        keys = new ArrayList<>();
        RowScanner rowScanner = new TextRowScanner(filename, ",");
        for (String[] values : rowScanner) {
            if (values.length == 0) {
                continue; // Skip empty lines
            }
            if (isNumericArray(values)) {
                try {
                    data.add(new Tuple(id, values));
                    keys.add(id++);
                } catch (NumberFormatException e) {
                    System.out.println("Ignoring invalid line: " + String.join(",", values));
                }
            } else {
                System.out.println("Ignoring invalid line: " + String.join(",", values));
            }
        }
        if (cardinality == 0 && !data.isEmpty()) {
            cardinality = data.size();
        }
        if (dimensionality == 0 && !data.isEmpty()) {
            dimensionality = data.get(0).size();
        }
        name = filename;
    }

    private boolean isNumericArray(String[] values) {
        for (String value : values) {
            try {
                Double.parseDouble(value);
            } catch (NumberFormatException e) {
                return false;
            }
        }
        return true;
    }

    public int size() {
        return data.size();
    }

    @Override
    public String toString() {
        return "Dataset{'" + name + ": dimensionality=" + dimensionality + ", size=" + data.size() + "}";
    }

    public class Iterator extends SimpleIterator {

        private int current = 0;

        @Override
        public SimpleIterator clone() {
            Iterator itr = new Iterator();
            itr.current = current;
            return itr;
        }

        @Override
        public void close() {
        }

        @Override
        public boolean hasNext() {
            return current < data.size();
        }

        @Override
        public Tuple next() {
            ++SIO;
            return data.get(current++);
        }
    }
}
