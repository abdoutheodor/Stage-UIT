package fr.lifat.skyline.type.index;

import fr.lifat.skyline.input.Dataset;
import fr.lifat.skyline.type.Index;
import fr.lifat.skyline.type.Tuple;

import java.util.ArrayList;
import java.util.Collections;

public class ListIndex extends Index<ArrayList<Entry>> {

    public void build(Dataset dataset) {
        super.build(dataset);
        for (int k = 0; k < dimensionality; ++k) {
            indexes.add(new ArrayList<>());
        }
        add(dataset);
        for (int k = 0; k < dimensionality; ++k) {
            Collections.sort(indexes.get(k));
        }
        reset();
    }

    protected void add(Tuple tuple, int k) {
        indexes.get(k).add(new Entry(tuple.id, tuple.get(k)));
    }
}
