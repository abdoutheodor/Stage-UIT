package fr.lifat.skyline.type;

import fr.lifat.skyline.input.Dataset;
import fr.lifat.skyline.type.index.Entry;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public abstract class Index<E extends Iterable<Entry>> {

    protected Dataset cache;
    protected int cardinality = 0;
    protected Entry[] currentEntry;
    protected Entry[] currentLastEntry;
    protected Tuple[] currentTuple;
    protected int dimensionality = 0;
    protected ArrayList<E> indexes = new ArrayList<>();
    protected ArrayList<Iterator<Entry>> iterators = new ArrayList<>();
    protected boolean[] peeked;

    public void build(Dataset dataset) {
        cache = dataset;
        cardinality = dataset.getCardinality();
        dimensionality = dataset.getDimensionality();
        currentEntry = new Entry[dimensionality];
        currentLastEntry = new Entry[dimensionality];
        currentTuple = new Tuple[dimensionality];
        peeked = new boolean[dimensionality];
    }

    public Tuple getCurrentTuple(int d) {
        return currentTuple[d];
    }

    public boolean hasNext(int d) {
        return iterators.get(d).hasNext();
    }

    public Entry next(int d) {
        currentLastEntry[d] = currentEntry[d];
        if (!peeked[d]) {
            currentEntry[d] = iterators.get(d).next();
            currentTuple[d] = cache.get(currentEntry[d].id);
        } else {
            peeked[d] = false;
        }
        return currentEntry[d];
    }

    public Entry peek(int d) {
        if (peeked == null) {
            peeked = new boolean[dimensionality];
            Arrays.fill(peeked, false);
        }
        peeked[d] = true;
        currentEntry[d] = iterators.get(d).hasNext() ? iterators.get(d).next() : null;
        currentTuple[d] = currentEntry[d] == null ? null : cache.get(currentEntry[d].id);
        return currentEntry[d];
    }

    public Entry previous(int d) {
        return currentLastEntry[d];
    }

    public void reset() {
        iterators.clear();
        for (Iterable<Entry> index : indexes) {
            iterators.add(index.iterator());
        }
        if (peeked == null) {
            peeked = new boolean[dimensionality];
        }
        Arrays.fill(peeked, false);
    }

    protected void add(Dataset dataset) {
        for (int i = 0; i < cardinality; ++i) {
            Tuple tuple = dataset.get(i);
            for (int k = 0; k < dimensionality; ++k) {
                add(tuple, k);
            }
        }
    }

    abstract protected void add(Tuple tuple, int k);
}
