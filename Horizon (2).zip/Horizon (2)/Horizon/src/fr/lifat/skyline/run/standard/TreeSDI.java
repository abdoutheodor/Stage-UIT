package fr.lifat.skyline.run.standard;

import fr.lifat.skyline.bench.Standard;
import fr.lifat.skyline.input.CsvFile;
import fr.lifat.skyline.type.index.TreeIndex;

public class TreeSDI {

    public static void main(String[] args) {
        fr.lifat.skyline.methods.standard.SDI.WITH_STOPLINE = true;
        new Standard<>(CsvFile.class).run(new fr.lifat.skyline.methods.standard.SDI<>(TreeIndex.class), args);
    }
}
