package fr.lifat.skyline.bench;

import fr.lifat.skyline.input.Dataset;
import fr.lifat.skyline.util.Timer;

public class Standard<D extends Dataset> {

    private final Class<D> datasetInstance;

    public Standard(Class<D> instance) {
        datasetInstance = instance;
    }

    public void run(fr.lifat.skyline.methods.Standard method, String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: " + method.getClass().getCanonicalName() + " FILE");
            return;
        }
        String f = args[0];
        Dataset dataset = null;
        try {
            dataset = datasetInstance.newInstance();
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(0);
        }
        dataset.load(f);
        method.assign(dataset);
        Timer timer = new Timer();
        timer.start();
        method.build();
        timer.stop();
        double build = timer.interval();
        System.out.println("# " + method.getName());
        System.out.println("# Build: " + build + " ms");
        System.out.println("# Cardinality: " + dataset.getCardinality());
        System.out.println("# Dimensionality: " + dataset.getDimensionality());
        timer.start();
        method.query();
        timer.stop();
        double query = timer.interval();
        double total = build + query;
        System.out.println("# Query: " + query + " ms");
        System.out.println("# Total: " + total + " ms");
        System.out.println("# Skyline: " + method.getSkyline().size());
        System.out.println("# DT: " + method.DT);
        System.out.println("# DT/Tuple: " + method.DT * 1.0 / dataset.getCardinality());
        System.out.println("# IO: " + dataset.IO);
        System.out.println("# SIO: " + dataset.SIO);
        System.out.println("# TESTED: " + method.TT);
    }
}
