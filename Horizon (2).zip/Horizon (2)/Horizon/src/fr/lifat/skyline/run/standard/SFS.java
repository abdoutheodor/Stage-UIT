package fr.lifat.skyline.run.standard;

import fr.lifat.skyline.bench.Standard;
import fr.lifat.skyline.input.CsvFile;

public class SFS {

    public static void main(String[] args) {
        new Standard<>(CsvFile.class).run(new fr.lifat.skyline.methods.standard.SFS(), args);
    }
}
