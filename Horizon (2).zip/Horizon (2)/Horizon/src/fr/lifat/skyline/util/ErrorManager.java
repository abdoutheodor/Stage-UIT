package fr.lifat.skyline.util;

public class ErrorManager {

    public static void exit(String message) {
        System.err.println(message);
        System.exit(0);
    }

    public static void exit(Exception e, String message) {
        System.err.println(message);
        System.err.println(e.getMessage());
        System.exit(0);
    }
}
