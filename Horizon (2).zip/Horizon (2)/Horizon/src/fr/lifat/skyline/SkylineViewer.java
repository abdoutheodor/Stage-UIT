package fr.lifat.skyline;

// Importations des classes nécessaires pour l'application
import fr.lifat.skyline.input.JdbcData;
import fr.lifat.skyline.input.CsvFile;
import fr.lifat.skyline.methods.standard.BNL;
import fr.lifat.skyline.util.Timer;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

// Déclaration de la classe principale
public class SkylineViewer extends JFrame {

    // Composants de l'interface utilisateur
    private JTextArea resultArea;
    private JTable table;
    private JScrollPane scrollPane;
    private String filePath;
    private JTextField jdbcUrlField;
    private JTextField jdbcUserField;
    private JPasswordField jdbcPasswordField;
    private JTextArea jdbcQueryArea;
    private JTextArea jdbcResultArea;
    private CardLayout cardLayout;
    private JPanel cardPanel;

    // Constructeur principal de l'application
    public SkylineViewer() {
        // Initialisation de la fenêtre principale
        setTitle("Visionneuse de Skyline");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialisation des panneaux avec un CardLayout pour la navigation
        cardPanel = new JPanel(new CardLayout());
        cardLayout = (CardLayout) cardPanel.getLayout();

        // Panneau de sélection de la source de données
        JPanel selectionPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Bouton pour l'utilisation de fichiers CSV
        JButton csvButton = new JButton("Utiliser CSV");
        csvButton.setBackground(new Color(102, 204, 255));
        csvButton.setForeground(Color.BLACK);
        csvButton.setFocusPainted(false);
        csvButton.setFont(new Font("Tahoma", Font.BOLD, 18));
        csvButton.addActionListener(e -> cardLayout.show(cardPanel, "csvPanel"));
        selectionPanel.add(csvButton, gbc);

        gbc.gridy++;
        // Bouton pour l'utilisation de JDBC
        JButton jdbcButton = new JButton("Utiliser JDBC");
        jdbcButton.setBackground(new Color(102, 204, 255));
        jdbcButton.setForeground(Color.BLACK);
        jdbcButton.setFocusPainted(false);
        jdbcButton.setFont(new Font("Tahoma", Font.BOLD, 18));
        jdbcButton.addActionListener(e -> cardLayout.show(cardPanel, "jdbcPanel"));
        selectionPanel.add(jdbcButton, gbc);

        // Création des panneaux pour CSV et JDBC
        JPanel csvPanel = createCsvPanel();
        JPanel jdbcPanel = createJdbcPanel();

        // Ajout des panneaux à la carte
        cardPanel.add(selectionPanel, "selectionPanel");
        cardPanel.add(csvPanel, "csvPanel");
        cardPanel.add(jdbcPanel, "jdbcPanel");

        // Ajout du panneau principal à la fenêtre
        add(cardPanel);
        cardLayout.show(cardPanel, "selectionPanel");
    }

    // Création du panneau pour l'utilisation de CSV
    private JPanel createCsvPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JLabel titleLabel = new JLabel("Visionneuse de Skyline - CSV");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(10, 10, 10, 10));
        titleLabel.setOpaque(true);
        titleLabel.setBackground(new Color(51, 153, 255));
        titleLabel.setForeground(Color.WHITE);

        JButton backButton = new JButton("Retour");
        backButton.setBackground(new Color(255, 102, 102));
        backButton.setForeground(Color.BLACK);
        backButton.setFocusPainted(false);
        backButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        backButton.addActionListener(e -> cardLayout.show(cardPanel, "selectionPanel"));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(backButton, BorderLayout.WEST);
        topPanel.add(titleLabel, BorderLayout.CENTER);

        // Bouton pour charger un fichier CSV
        JButton loadButton = new JButton("Charger CSV");
        loadButton.setBackground(new Color(102, 204, 255));
        loadButton.setForeground(Color.BLACK);
        loadButton.setFocusPainted(false);
        loadButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        loadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int returnValue = fileChooser.showOpenDialog(null);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    filePath = fileChooser.getSelectedFile().getPath();
                    if (!filePath.toLowerCase().endsWith(".csv")) {
                        showErrorDialog("Veuillez sélectionner un fichier CSV.");
                        return;
                    }
                    displayCSVContent(filePath);
                }
            }
        });

        // Bouton pour calculer le Skyline à partir du CSV
        JButton computeButton = new JButton("Calculer Skyline");
        computeButton.setBackground(new Color(102, 204, 255));
        computeButton.setForeground(Color.BLACK);
        computeButton.setFocusPainted(false);
        computeButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        computeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                computeSkylineCSV();
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.add(loadButton);
        buttonPanel.add(computeButton);

        resultArea = new JTextArea(15, 50);
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Courier New", Font.PLAIN, 12));
        resultArea.setBackground(new Color(230, 230, 250));
        resultArea.setBorder(BorderFactory.createLineBorder(new Color(102, 204, 255)));

        table = new JTable();
        table.setFont(new Font("SansSerif", Font.PLAIN, 12));
        table.setBackground(new Color(245, 245, 245));
        table.setFillsViewportHeight(true);

        scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Données CSV"));

        JPanel middlePanel = new JPanel(new GridLayout(1, 2));
        middlePanel.add(scrollPane);
        middlePanel.add(new JScrollPane(resultArea));

        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(middlePanel, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    // Création du panneau pour l'utilisation de JDBC
    private JPanel createJdbcPanel() {
        JPanel jdbcPanel = new JPanel(new BorderLayout());

        JLabel titleLabel = new JLabel("Visionneuse de Skyline - JDBC");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBorder(new EmptyBorder(10, 10, 10, 10));
        titleLabel.setOpaque(true);
        titleLabel.setBackground(new Color(51, 153, 255));
        titleLabel.setForeground(Color.WHITE);

        JButton backButton = new JButton("Retour");
        backButton.setBackground(new Color(255, 102, 102));
        backButton.setForeground(Color.BLACK);
        backButton.setFocusPainted(false);
        backButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        backButton.addActionListener(e -> cardLayout.show(cardPanel, "selectionPanel"));

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(backButton, BorderLayout.WEST);
        topPanel.add(titleLabel, BorderLayout.CENTER);

        JPanel jdbcInputPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbcJdbcInput = new GridBagConstraints();
        gbcJdbcInput.gridx = 0;
        gbcJdbcInput.gridy = 0;
        gbcJdbcInput.insets = new Insets(5, 5, 5, 5);
        gbcJdbcInput.anchor = GridBagConstraints.WEST;

        jdbcInputPanel.add(new JLabel("URL de la base de données :"), gbcJdbcInput);
        jdbcUrlField = new JTextField(20);
        gbcJdbcInput.gridx = 1;
        jdbcInputPanel.add(jdbcUrlField, gbcJdbcInput);

        gbcJdbcInput.gridx = 0;
        gbcJdbcInput.gridy = 1;
        jdbcInputPanel.add(new JLabel("Nom d'utilisateur :"), gbcJdbcInput);
        jdbcUserField = new JTextField(20);
        gbcJdbcInput.gridx = 1;
        jdbcInputPanel.add(jdbcUserField, gbcJdbcInput);

        gbcJdbcInput.gridx = 0;
        gbcJdbcInput.gridy = 2;
        jdbcInputPanel.add(new JLabel("Mot de passe :"), gbcJdbcInput);
        jdbcPasswordField = new JPasswordField(20);
        gbcJdbcInput.gridx = 1;
        jdbcInputPanel.add(jdbcPasswordField, gbcJdbcInput);

        gbcJdbcInput.gridx = 0;
        gbcJdbcInput.gridy = 3;
        gbcJdbcInput.gridwidth = 2;
        jdbcInputPanel.add(new JLabel("Requête SQL :"), gbcJdbcInput);
        jdbcQueryArea = new JTextArea(5, 20);
        gbcJdbcInput.gridy = 4;
        jdbcInputPanel.add(new JScrollPane(jdbcQueryArea), gbcJdbcInput);

        // Bouton pour charger les données via JDBC
        JButton loadJdbcButton = new JButton("Charger JDBC");
        loadJdbcButton.setBackground(new Color(102, 204, 255));
        loadJdbcButton.setForeground(Color.BLACK);
        loadJdbcButton.setFocusPainted(false);
        loadJdbcButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        loadJdbcButton.addActionListener(e -> loadJdbcData());

        // Bouton pour calculer le Skyline à partir des données JDBC
        JButton computeJdbcButton = new JButton("Calculer Skyline JDBC");
        computeJdbcButton.setBackground(new Color(102, 204, 255));
        computeJdbcButton.setForeground(Color.BLACK);
        computeJdbcButton.setFocusPainted(false);
        computeJdbcButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        computeJdbcButton.addActionListener(e -> computeSkylineJDBC());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(240, 240, 240));
        buttonPanel.add(loadJdbcButton);
        buttonPanel.add(computeJdbcButton);

        jdbcResultArea = new JTextArea(15, 50);
        jdbcResultArea.setEditable(false);
        jdbcResultArea.setFont(new Font("Courier New", Font.PLAIN, 12));
        jdbcResultArea.setBackground(new Color(230, 230, 250));
        jdbcResultArea.setBorder(BorderFactory.createLineBorder(new Color(102, 204, 255)));

        JPanel middlePanel = new JPanel(new GridLayout(1, 2));
        middlePanel.add(jdbcInputPanel);
        middlePanel.add(new JScrollPane(jdbcResultArea));

        jdbcPanel.add(topPanel, BorderLayout.NORTH);
        jdbcPanel.add(middlePanel, BorderLayout.CENTER);
        jdbcPanel.add(buttonPanel, BorderLayout.SOUTH);

        return jdbcPanel;
    }

    // Méthode pour afficher le contenu du fichier CSV dans le tableau
    private void displayCSVContent(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            List<String[]> data = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                data.add(line.split(","));
            }
            if (!data.isEmpty()) {
                String[] columnNames = data.get(0);
                String[][] tableData = data.subList(1, data.size()).toArray(new String[0][]);
                table.setModel(new DefaultTableModel(tableData, columnNames));
            }
        } catch (IOException e) {
            showError(resultArea, "Erreur lors du chargement du fichier CSV : " + e.getMessage());
        }
    }

    // Méthode pour calculer le Skyline à partir des données CSV
    private void computeSkylineCSV() {
        if (filePath == null || filePath.isEmpty()) {
            showError(resultArea, "Aucun fichier CSV chargé. Veuillez charger un fichier CSV d'abord.");
            return;
        }

        System.out.println("Chargement du fichier CSV : " + filePath);
        try {
            CsvFile csvFile = new CsvFile();
            csvFile.load(filePath);
            BNL bnl = new BNL();
            fr.lifat.skyline.methods.Standard standard = new fr.lifat.skyline.methods.standard.BNL();
            standard.assign(csvFile);

            Timer skylineTimer = new Timer();
            skylineTimer.start();
            standard.build();
            skylineTimer.stop();
            double build = skylineTimer.interval();

            skylineTimer.start();
            standard.query();
            skylineTimer.stop();
            double query = skylineTimer.interval();
            double total = build + query;

            System.out.println("Calcul de Skyline terminé");

            resultArea.setText("");
            resultArea.append("# " + standard.getName() + "\n");
            resultArea.append("# Construction : " + build + " ms\n");
            resultArea.append("# Cardinalité : " + csvFile.getCardinality() + "\n");
            resultArea.append("# Dimensionalité : " + csvFile.getDimensionality() + "\n");
            resultArea.append("# Requête : " + query + " ms\n");
            resultArea.append("# Total : " + total + " ms\n");
            resultArea.append("# Skyline : " + standard.getSkyline().size() + "\n");
            resultArea.append("# DT : " + standard.DT + "\n");
            resultArea.append("# DT/Tuple : " + standard.DT * 1.0 / csvFile.getCardinality() + "\n");
            resultArea.append("# IO : " + csvFile.IO + "\n");
            resultArea.append("# SIO : " + csvFile.SIO + "\n");
            resultArea.append("# TESTÉ : " + standard.TT + "\n");

            highlightSkylineRows(table, standard.getSkyline());
            System.out.println("Résultats affichés dans JTextArea");
        } catch (Exception e) {
            showError(resultArea, "Erreur lors du calcul des Skylines : " + e.getMessage());
        }
    }

    // Méthode pour charger les données JDBC
    private void loadJdbcData() {
        String dbUrl = jdbcUrlField.getText();
        String dbUser = jdbcUserField.getText();
        String dbPassword = new String(jdbcPasswordField.getPassword());
        String query = jdbcQueryArea.getText();

        if (dbUrl.isEmpty() || dbUser.isEmpty() || dbPassword.isEmpty() || query.isEmpty()) {
            showErrorDialog("Veuillez remplir tous les champs.");
            return;
        }

        jdbcResultArea.setText("Chargement des données JDBC : " + dbUrl);

        try {
            JdbcData jdbcData = new JdbcData(dbUrl, dbUser, dbPassword);
            jdbcData.load(query);

            BNL bnl = new BNL();
            fr.lifat.skyline.methods.Standard standard = new fr.lifat.skyline.methods.standard.BNL();
            standard.assign(jdbcData);

            Timer skylineTimer = new Timer();
            skylineTimer.start();
            standard.build();
            skylineTimer.stop();
            double build = skylineTimer.interval();

            skylineTimer.start();
            standard.query();
            skylineTimer.stop();
            double queryTime = skylineTimer.interval();
            double total = build + queryTime;

            jdbcResultArea.setText("");
            jdbcResultArea.append("# " + standard.getName() + "\n");
            jdbcResultArea.append("# Construction : " + build + " ms\n");
            jdbcResultArea.append("# Cardinalité : " + jdbcData.getCardinality() + "\n");
            jdbcResultArea.append("# Dimensionalité : " + jdbcData.getDimensionality() + "\n");
            jdbcResultArea.append("# Requête : " + queryTime + " ms\n");
            jdbcResultArea.append("# Total : " + total + " ms\n");
            jdbcResultArea.append("# Skyline : " + standard.getSkyline().size() + "\n");
            jdbcResultArea.append("# DT : " + standard.DT + "\n");
            jdbcResultArea.append("# DT/Tuple : " + standard.DT * 1.0 / jdbcData.getCardinality() + "\n");
            jdbcResultArea.append("# IO : " + jdbcData.IO + "\n");
            jdbcResultArea.append("# SIO : " + jdbcData.SIO + "\n");
            jdbcResultArea.append("# TESTÉ : " + standard.TT + "\n");

            System.out.println("Résultats affichés dans JTextArea");
        } catch (Exception e) {
            showErrorDialog("Erreur inattendue : " + e.getMessage());
        }
    }

    // Méthode pour calculer le Skyline à partir des données JDBC
    private void computeSkylineJDBC() {
        // Cette méthode n'est pas nécessaire si vous chargez et calculez dans loadJdbcData()
    }

    // Méthode pour mettre en évidence les lignes du tableau correspondant au Skyline
    private void highlightSkylineRows(JTable table, List<Integer> skylineRows) {
        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (skylineRows.contains(row)) {
                    c.setBackground(Color.YELLOW);
                } else {
                    c.setBackground(table.getBackground());
                }
                return c;
            }
        });
    }

    // Méthode pour afficher les messages d'erreur dans le JTextArea
    private void showError(JTextArea textArea, String message) {
        textArea.setForeground(Color.RED);
        textArea.setText(message);
    }

    // Méthode pour afficher une boîte de dialogue d'erreur
    private void showErrorDialog(String message) {
        JOptionPane.showMessageDialog(this, message, "Erreur", JOptionPane.ERROR_MESSAGE);
    }

    // Méthode principale pour démarrer l'application
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SkylineViewer().setVisible(true));
    }
}
